//
//  TableCell.swift
//  SafeLineUCI
//
//  Created by meta novitia on 2/16/19.
//  Copyright © 2019 foo. All rights reserved.
//

import UIKit

class TableCell: UITableViewCell {
    
    
    @IBOutlet weak var cellimage: UIImageView!
    @IBOutlet weak var celllabel: UILabel!
    @IBOutlet weak var celltime: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        cellimage.layer.cornerRadius = 30
        cellimage.clipsToBounds = true
        cellimage.layer.borderColor = UIColor.white.cgColor
        cellimage.layer.borderWidth = 3
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
