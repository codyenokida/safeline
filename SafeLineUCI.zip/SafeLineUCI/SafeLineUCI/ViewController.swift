//
//  ViewController.swift
//  SafeLineUCI
//
//  Created by meta novitia on 2/15/19.
//  Copyright © 2019 foo. All rights reserved.
//

import UIKit
import CoreData
import Firebase

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var password_input: UITextField!
    
    let border1 = CALayer()
    let border2 = CALayer()
//    var value :[String] = []
//    var value2 :[String] = []
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var loginbtn: UIButton!
    @IBOutlet weak var signup_btn: UIButton!
    @IBOutlet weak var username_input: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)

        let width = CGFloat(2.0)
        border1.borderColor = UIColor.white.cgColor
        border1.frame = CGRect(x: 0, y: password_input.frame.size.height - width, width: password_input.frame.size.width, height: password_input.frame.size.height)
        
        border2.borderColor = UIColor.white.cgColor
        border2.frame = CGRect(x: 0, y: username_input.frame.size.height - width, width: username_input.frame.size.width, height: username_input.frame.size.height)
        
        border1.borderWidth = width
        border2.borderWidth = width
        password_input.layer.addSublayer(border1)
        password_input.layer.masksToBounds = true
        username_input.layer.addSublayer(border2)
        username_input.layer.masksToBounds = true
        self.password_input.delegate = self
        self.username_input.delegate = self
        
        username_input.text = ""
        password_input.text = ""
        
        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
//        ref.child("data").observeSingleEvent(of: .value, with: { (snapshot) in
//            // Get user value
//            for child in snapshot.children {
////                print((child as AnyObject).value as String);
//                let value = (child as! DataSnapshot).value as? NSDictionary
//                self.value.append(value?["Time"] as? String? as! String)
//                self.value2.append(value?["Img"] as? String? as! String)
//
//            }
//
//
//            // ...
//        }) { (error) in
//            print(error.localizedDescription)
//        }
        
        
    }
    
    @IBAction func onClickLogin(_ sender: Any) {
        
        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
        ref.child("users").child(username_input.text!).child("Password").observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? String
            if(value==self.password_input.text){
                
                let entity = NSEntityDescription.entity(forEntityName: "User", in: self.context)
                let newUser = NSManagedObject(entity: entity!, insertInto: self.context)
                
                newUser.setValue(self.username_input.text, forKey: "username")
                
                do {
                    try self.context.save()
                } catch {
                    print("Failed saving")
                }
                
                self.performSegue(withIdentifier: "LoggedIn", sender: self)
            }
            else{
                self.border1.borderColor = UIColor.red.cgColor
                self.border2.borderColor = UIColor.red.cgColor
            }
            // ...
        }) { (error) in
            print(error.localizedDescription)
            self.border1.borderColor = UIColor.red.cgColor
            self.border2.borderColor = UIColor.red.cgColor
        }
        
        
        
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
    }
    
    func textFieldShouldReturn( _: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! secondViewController
        vc.username = username_input.text as! String
//        vc.value = value
//        vc.value2 = value2
//        print(value)
    }
}


