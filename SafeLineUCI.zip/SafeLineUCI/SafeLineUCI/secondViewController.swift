//
//  ViewController.swift
//  SafeLineUCI
//
//  Created by meta novitia on 2/15/19.
//  Copyright © 2019 foo. All rights reserved.
//

import UIKit
import Firebase
import UserNotifications

class secondViewController: UIViewController, UITextFieldDelegate, UITableViewDataSource, UNUserNotificationCenterDelegate {
    
    
    @IBOutlet weak var tableView: UITableView!
    var username : String?
    
    var value: [String] = []
    var value2: [String] = []
    @IBOutlet weak var welcome: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        
        tableView.rowHeight = 280
        
        tableView.dataSource = self
        welcome.text = "Welcome back, " + username!
        
        var ref: DatabaseReference!
        
        ref = Database.database().reference()
        
        
        ref.child("data").observe(.childAdded, with: { (snapshot) -> Void in
            if(snapshot.value != nil){
                
                let v = snapshot.value as? NSDictionary
                if(v?["Time"] != nil){
                    self.value.append(v?["Time"] as? String? as! String)
                    self.value2.append(v?["Img"] as? String? as! String)
                    self.tableView.insertRows(at: [IndexPath(row: self.value.count-1, section: 0)], with: UITableView.RowAnimation.automatic)
                    
                let content = UNMutableNotificationContent()
                    content.title = "Help!"
                    content.body = "One of your loved ones have fallen :("
                    content.sound = UNNotificationSound.default
                    
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
                    
                let request = UNNotificationRequest(identifier: "testIdentifier", content: content, trigger: trigger)
                    
                UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
                    
                    
                    
                }
            }
        })
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(value.count)
        return (value.count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cellReuseIdentifier", for: indexPath) as? TableCell  else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        
        let text = value[value.count-indexPath.row-1] //2.
        var newT = text.components(separatedBy: " ")
        let date = newT[0] + ", " + newT[1] + " " + newT[2]
        
        
        
        let im = value2[value.count-indexPath.row-1] //2.
        let dataDecoded : Data = Data(base64Encoded: im, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        tableView.layer.borderColor=UIColor.white.cgColor;
        cell.celllabel?.text = date //3.
        cell.cellimage?.image = decodedimage
        cell.celltime?.text = newT[3]
        
        
        return cell //4.
    }
    
    
    
}

